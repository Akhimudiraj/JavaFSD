import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.html',
  standalone:false,
  styleUrls: ['./signup.css']
})
export class Signup implements OnInit {

    signupForm!: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
    this.signupForm = this.fb.group({
      fullname: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validator: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup) {
    return form.get('password')!.value === form.get('confirmPassword')!.value
      ? null : { mismatch: true };
  }

  // <-- Replace your old signupUser() with this one
  signupUser() {
    this.submitted = true;
    if (this.signupForm.invalid) return;

    // Save login state
    localStorage.setItem('isLoggedIn', 'true');

    alert('Signup successful! Redirecting to Dashboard.');
    this.router.navigate(['/dashboard']);
  }

  get f() { return this.signupForm.controls; }
}
