import { Component } from '@angular/core';

@Component({
  selector: 'app-non-veg',
  standalone: false,
  templateUrl: './non-veg.html',
  styleUrl: './non-veg.css',
})
export class NonVeg {

}
