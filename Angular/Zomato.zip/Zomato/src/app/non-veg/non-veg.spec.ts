import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NonVeg } from './non-veg';

describe('NonVeg', () => {
  let component: NonVeg;
  let fixture: ComponentFixture<NonVeg>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NonVeg]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NonVeg);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
