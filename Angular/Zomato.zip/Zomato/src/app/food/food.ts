import { Component } from '@angular/core';

@Component({
  selector: 'app-food',
  standalone: false,
  templateUrl: './food.html',
  styleUrl: './food.css',
})
export class Food {

}
