import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Home } from './home/home';
import { Dashboard } from './dashboard/dashboard';
import { Login } from './login/login';
import { Signup } from './signup/signup';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Food } from './food/food';
import { Veg } from './veg/veg';
import { NonVeg } from './non-veg/non-veg';

@NgModule({
  declarations: [
    App,
    Home,
    Dashboard,
    Login,
    Signup,
    Food,
    Veg,
    NonVeg
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
   
  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }
