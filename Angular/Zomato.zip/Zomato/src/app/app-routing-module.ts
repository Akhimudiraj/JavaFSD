import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './home/home';
import { Dashboard } from './dashboard/dashboard';
import { Login } from './login/login';
import { Signup } from './signup/signup';
import { Food } from './food/food';

const routes: Routes = [

    { path: '', redirectTo: 'signup', pathMatch: 'full' },
  {
    path:'home',
    component:Home
  },
  {
    path:'dashboard',
    component:Dashboard
  },
  {
    path:'login',
    component:Login
  },
  {
    path:'signup',
    component:Signup
  },{
    path:'food',
    component:Food
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
