import { Component } from '@angular/core';

@Component({
  selector: 'app-veg',
  standalone: false,
  templateUrl: './veg.html',
  styleUrl: './veg.css',
})
export class Veg {

}
