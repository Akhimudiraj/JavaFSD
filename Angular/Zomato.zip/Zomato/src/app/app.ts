import { Component, signal } from '@angular/core';

import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.css'
})
export class App {
   protected readonly title = signal('Zomato');

  // Signal to track login state
  isLoggedIn = signal(false);

  constructor(private router: Router) {
    // Check localStorage on app load
    this.isLoggedIn.set(localStorage.getItem('isLoggedIn') === 'true');

    // Optional: update login state on every navigation
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.isLoggedIn.set(localStorage.getItem('isLoggedIn') === 'true');
      }
    });
  }

  logout() {
    localStorage.removeItem('isLoggedIn');
    this.isLoggedIn.set(false);
    this.router.navigate(['/login']);
  }
}
